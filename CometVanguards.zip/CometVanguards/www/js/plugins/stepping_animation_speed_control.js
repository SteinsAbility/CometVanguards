Game_CharacterBase.prototype.animationWait = function() {
    return 8;
};